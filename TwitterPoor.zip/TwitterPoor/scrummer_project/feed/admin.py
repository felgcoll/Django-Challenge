from django.contrib import admin
from .models import tweet
# Register your models here.

admin.site.register(tweet)