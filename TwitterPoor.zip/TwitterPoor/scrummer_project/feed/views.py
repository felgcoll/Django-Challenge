from django.shortcuts import render
from .models import tweet
from django.views.generic import ListView
from django.contrib.auth.mixins import LoginRequiredMixin
# Create your views here.

class TweetListView(LoginRequiredMixin,ListView):
    model = tweet
    template_name = 'feed/home.html'
    ordering = ['-datetime']