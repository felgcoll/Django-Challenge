from django import forms
from django.contrib.auth.models import User, Users
from django.auth.forms import UserCreationForm

class RegisterForm(UserCreationForm):
    email = forms.EmailField()

    class Meta:
        model = User
        field = ['username', 'tweet']
